package core

import (
	"fmt"
	"strings"

	"github.com/fatih/color"
)

const (
	VERSION = "4.0.0"
)

func putAsciiArt(s string) {
	for _, c := range s {
		d := string(c)
		switch {
		case d == " ":
			color.Set(color.FgBlack) // Default to black for spaces
			d = " "
		case strings.Contains("_|", d): // Border elements in yellow
			color.Set(color.FgYellow)
		case d == "x" || d == "X": // "x" or "X" in red
			color.Set(color.FgHiRed)
		case d == "v" || d == "V": // "v" or "V" in blue
			color.Set(color.FgHiBlue)
		case d == "█": // Specific character "█" in red
			color.Set(color.FgHiRed)
		case d == "╔" || d == "╚": // Characters "╔" and "╚" in green
			color.Set(color.FgGreen)
		case d == "═": // Character "═" in cyan
			color.Set(color.FgCyan)
		case d == "║": // Character "║" in magenta
			color.Set(color.FgMagenta)
		case d == "░": // Character "░" in yellow
			color.Set(color.FgYellow)
		case strings.Contains("𝗣𝗥𝗢𝗩𝗘𝗦𝗜𝗡𝗗𝗜𝗢𝗡☠", d): // PRO VERSION text in yellow
			color.Set(color.FgYellow)
        case strings.Contains("4.0.0", d): // VERSION number in green
			color.Set(color.FgGreen)	
		case d == "\n": // Reset color on newline
			color.Unset()
		default:
			color.Set(color.FgHiBlack) // Default all other characters to black
		}
		fmt.Print(d)
	}
	color.Unset()
}


func printLogo(s string) {
	for _, c := range s {
		d := string(c)
		switch d {
		case "_":
			color.Set(color.FgYellow) // Change color to yellow
		case "\n":
			color.Unset()
		default:
			color.Set(color.FgHiBlack)
		}
		fmt.Print(d)
	}
	color.Unset()
}

func printUpdateName() {
	nameClr := color.New(color.FgYellow) // Change color to yellow
	txt := nameClr.Sprintf("")
	fmt.Fprintf(color.Output, "%s", txt)
}

func printOneliner1() {
	handleClr := color.New(color.FgHiBlue)
	versionClr := color.New(color.FgGreen)
	textClr := color.New(color.FgHiBlack)
	spc := strings.Repeat(" ", 10-len(VERSION))
	txt := textClr.Sprintf("      by Fabrikano (") + handleClr.Sprintf("@xverginiaofficial") + textClr.Sprintf(")") + spc + textClr.Sprintf("version ") + versionClr.Sprintf("%s", VERSION)
	fmt.Fprintf(color.Output, "%s", txt)
}

func printOneliner2() {
	textClr := color.New(color.FgHiBlack)
	red := color.New(color.FgRed)
	white := color.New(color.FgWhite)
	txt := textClr.Sprintf("") + red.Sprintf("") + white.Sprintf("") + textClr.Sprintf("") + red.Sprintf("")
	fmt.Fprintf(color.Output, "%s", txt)
}

func Banner() {
	fmt.Println()

	// Display the new ASCII art banner with yellow border and red content
	putAsciiArt(`
 _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _ 
|_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_|
|_|                                                                  |_|
|_|                                                                  |_|
|_|██╗░░██╗██╗░░░██╗███████╗██████╗░░██████╗░██╗███╗░░██╗██╗░█████╗░ |_|
|_|╚██╗██╔╝██║░░░██║██╔════╝██╔══██╗██╔════╝░██║████╗░██║██║██╔══██╗ |_|
|_|░╚███╔╝░╚██╗░██╔╝█████╗░░██████╔╝██║░░██╗░██║██╔██╗██║██║███████║ |_|
|_|░██╔██╗░░╚████╔╝░██╔══╝░░██╔══██╗██║░░╚██╗██║██║╚████║██║██╔══██║ |_|
|_|██╔╝╚██╗░░╚██╔╝░░███████╗██║░░██║╚██████╔╝██║██║░╚███║██║██║░░██║ |_|
|_|╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═╝░░╚═╝░╚═════╝░╚═╝╚═╝░░╚══╝╚═╝╚═╝░░╚═╝ |_|
|_| ☠  𝗣𝗥𝗢 𝗩𝗘𝗥𝗦𝗜𝗢𝗡  ☠                             VERSION = 4.0.0    |_|
|_| _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _ |_|
|_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_|

`)

	printUpdateName()
	fmt.Println()

	printOneliner1()
	fmt.Println()

	printOneliner2()
	fmt.Println()
	fmt.Println()
}
