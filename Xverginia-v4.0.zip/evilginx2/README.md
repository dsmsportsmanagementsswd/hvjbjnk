*********************** Xverginia | SHOP ***********************

First install Go:

apt update 

apt install wget -y

wget https://dl.google.com/go/go1.19.8.linux-amd64.tar.gz

sudo tar -zxvf go1.19.8.linux-amd64.tar.gz -C /usr/local/

---------------------------------------------------------------
nano ~/.profile

export GOPATH=$HOME/go
export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin
---------------------------------------------------------------

clear

source ~/.profile

sudo apt-get -y install git make

---------------------------------------------------------------
Note : You need to buy the version from owner !! then continue put commands
---------------------------------------------------------------

cd evilginx2

mv evilginx2 xverginia1


make

./xverginia1 -p ./phishlets



*********************** Xverginia | SHOP *********************** 

Channel:
https://t.me/xverginiaofficial

Contact us:
https://t.me/fabrikano
https://t.me/xverginiasupport
